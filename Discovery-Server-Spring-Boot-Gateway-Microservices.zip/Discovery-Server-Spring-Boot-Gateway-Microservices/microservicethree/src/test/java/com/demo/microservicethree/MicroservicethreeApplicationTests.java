package com.demo.microservicethree;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicethreeApplicationTests {

	@Test
	void contextLoads() {
	}

}
