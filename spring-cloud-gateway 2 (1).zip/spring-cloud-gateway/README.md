# Spring Cloud Gateway Tutorial

Example gateway code and 2 sample microservices to depict routing mechanism.

## Getting Started

These instructions will get you a copy of the project up and running on your local machine for development and testing purposes. 

### Prerequisites

* Java 1.8
* Spring boot 2.1.5


### Installing

Download nt-sc-gw, nt-ms1 and nt-ms2 projects in to your STS or Eclipse workspace. 
