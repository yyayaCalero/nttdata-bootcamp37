package com.nt.msgw;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NtScGwApplication {

	public static void main(String[] args) {
		SpringApplication.run(NtScGwApplication.class, args);
	}

}
