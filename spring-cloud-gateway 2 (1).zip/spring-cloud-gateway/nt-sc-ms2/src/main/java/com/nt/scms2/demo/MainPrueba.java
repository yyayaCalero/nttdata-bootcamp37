package com.nt.scms2.demo;

import java.util.stream.Stream;

public class MainPrueba {
    public static void main (String []args){




        MyFuntionalnterface saludar = (String s) -> {
            return  "buenas tardes : " + s;
        };

        System. out.println(saludar.saludar("Jorge"));

    }
}
