package com.nt.scms2.demo;

@FunctionalInterface
public interface MyFuntionalnterface {
     String saludar( String name);
}
